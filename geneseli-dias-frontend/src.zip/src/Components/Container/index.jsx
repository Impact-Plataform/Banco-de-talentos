import "./style.css";

export default Container(props);{
     return (
        <div className="container">
            {props.children}
        </div>
    )
};

   