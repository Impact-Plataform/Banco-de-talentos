export default function ModalDetails() {
    return (
        <div className="modal-details">
            
        </div>
    )
}