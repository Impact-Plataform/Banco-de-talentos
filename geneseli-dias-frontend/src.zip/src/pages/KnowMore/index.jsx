export default function KnowMore() {
    return (
        <div className="know-more">
            
        </div>
    )
}